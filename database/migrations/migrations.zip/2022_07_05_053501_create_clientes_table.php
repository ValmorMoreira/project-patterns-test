<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateClientesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('clientes', function (Blueprint $table) {
            // $table->BigInteger('cli_id', true);
            // $table->string('cli_fantasia');
            // $table->string('cli_responsavel');
            // $table->string('cli_doctipo');
            // $table->string('cli_docnumero');
            // $table->timestamps();

            $table->id("cli_id");
            $table->string("cli_fantasia", 255);
            $table->string("cli_responsavel", 255);
            $table->string("cli_doctipo", 5);
            $table->string("cli_docnumero", 50);
            $table->timestamp("cli_timestamp");
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('clientes');
    }
}
